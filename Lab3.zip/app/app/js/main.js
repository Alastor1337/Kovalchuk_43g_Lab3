let count = 1;

$(document).ready(function() {
    countCheckBtn();
    countCheckPlace();
    countCheckBlock();
});

$('#choose-button-1').click(function() {
    countCheckBtn();
    countCheckPlace();
    countCheckBlock();
    $("#target-1").toggleClass('display-block');
    $('.choose__block-1').toggleClass('block__active');
    $("#pay-card").toggleClass('display-block-2');
    count = 1;
});

$('#choose-button-2').click(function() {
    countCheckBtn();
    countCheckPlace();
    countCheckBlock();
    $("#target-2").toggleClass('display-block');
    $('.choose__block-2').toggleClass('block__active');
    $("#paypal").toggleClass('display-block-2');
    count = 2;
});

$('#choose-button-3').click(function() {
    countCheckBtn();
    countCheckPlace();
    countCheckBlock();
    $("#target-3").toggleClass('display-block');
    $('.choose__block-3').toggleClass('block__active');
    $("#amazon").toggleClass('display-block-2');
    count = 3;
});

function countCheckBlock(){
    if (count === 1){
        $("#pay-card").toggleClass('display-block-2');
    }
    if (count === 2){
        $("#paypal").toggleClass('display-block-2');
    }
    if (count === 3){
        $("#amazon").toggleClass('display-block-2');
    }
}

function countCheckBtn() {
    if (count === 1){
        $("#target-1").toggleClass('display-block');
    }
    if (count === 2){
        $("#target-2").toggleClass('display-block');
    }
    if (count === 3){
        $("#target-3").toggleClass('display-block');
    }
}

function countCheckPlace(){
    if (count === 1){
        $('.choose__block-1').toggleClass('block__active');
    }
    if (count === 2){
        $('.choose__block-2').toggleClass('block__active');
    }
    if (count === 3){
        $('.choose__block-3').toggleClass('block__active');
    }
}